#include <stdio.h>
#include <stdlib.h>

#define TAILLE1 10

struct Exo
{
    float f;
    float tab1[TAILLE1];
    int taille2;
    float *tab2;
};

// todo : fonction init (la structure est déjà allouée)

// todo : fonction creer

// todo : fonction liberer


int main()
{
    // todo : appeler creer et liberer
    
    return EXIT_SUCCESS;
}
