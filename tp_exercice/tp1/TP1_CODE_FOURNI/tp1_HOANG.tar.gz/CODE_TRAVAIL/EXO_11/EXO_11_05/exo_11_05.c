#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "motif.h"

/*
 * création dynamique du tableau à deux dimensions
 * utilisation de la fonction isOn pour l'initialiser
 */
// todo : écrire la fonction creer

/*
 * affichage du tableau
 * - on affiche les axes
 * - attention à l'ordre de parcours des dimensions
 * - attention : affichage de haut en bas, mais les y vont de bas en haut
 */
// todo : écrire la fonction afficher

/*
 * libération des ressources
 */
// todo : écrire la fonction liberer


int main()
{
    // appel fonction créer pour un tableau de taille NX x NY (cf. motif.h)
    // appel fonction afficher
    // appel fonction liberer
    
    return EXIT_SUCCESS;
}
