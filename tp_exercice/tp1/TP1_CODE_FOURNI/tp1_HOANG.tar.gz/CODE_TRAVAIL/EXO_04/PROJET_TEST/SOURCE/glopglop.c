#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("glopglop\n");
    return EXIT_SUCCESS;
}
