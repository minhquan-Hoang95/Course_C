// todo
#include<stdio.h>
#include<stdlib.h>

int main()
{
	printf("Hello, wolrd\n");
	fprintf(stdout,"Je suis la\n");
	fprintf(stderr, "Il y a une erreur de ...\n");
	
	return EXIT_SUCCESS;
}
